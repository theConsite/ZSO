#!/bin/bash
gcc proj.c -o Proj_2 -lm -lpthread -Ddebug